"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X } from "lucide-react";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white/70 backdrop-blur-xl border-b border-white/40 shadow-[0_10px_30px_rgba(15,23,42,0.08)]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-slate-900 bg-clip-text text-transparent">
              ClickFob
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <Link
              href="/#services"
              className="text-gray-600 hover:text-indigo-600 transition-colors font-medium"
            >
              Services
            </Link>
            <Link
              href="/manage"
              className="text-gray-600 hover:text-indigo-600 transition-colors font-medium"
            >
              Manage Booking
            </Link>
            <a
              href="https://wa.me/14167707036"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-600 hover:text-indigo-600 transition-colors font-medium"
            >
              WhatsApp
            </a>
            <Link
              href="/book"
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-semibold transition-all shadow-md hover:shadow-lg"
            >
              Book Now
            </Link>
          </nav>

          <button
            className="md:hidden p-2 text-gray-600"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-100">
            <nav className="flex flex-col gap-3">
              <Link
                href="/#services"
                className="text-gray-600 hover:text-indigo-600 transition-colors font-medium py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                Services
              </Link>
              <Link
                href="/manage"
                className="text-gray-600 hover:text-indigo-600 transition-colors font-medium py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                Manage Booking
              </Link>
              <Link
                href="/book"
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-semibold transition-all text-center"
                onClick={() => setMobileMenuOpen(false)}
              >
                Book Now
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
